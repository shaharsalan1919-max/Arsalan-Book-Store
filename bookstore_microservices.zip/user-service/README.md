# User Service (Node.js + Express)

Features:
- Sign up
- Login
- Simple profile retrieval

Environment variables used:
- DB_HOST, DB_USER, DB_PASS, DB_NAME

For demo we use MySQL (see docker-compose.yml). Password storage in this demo is NOT secure — replace with hashing in real projects.
